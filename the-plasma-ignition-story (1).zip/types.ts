
export interface IgnitionSystem {
  name: string;
  howItWorks: string;
  activationEnergy: string;
  problems: string[];
  efficiency: string;
}

export interface PlasmaPerformanceData {
  fuelSystem: string;
  thermalBaseline: string;
  plasmaPathway: string;
  efficiencyImprovement: string;
  ignitionDelay?: string;
  powerRequirement?: string;
}

export interface ComparisonMetric {
  metric: string;
  bestCurrent: string;
  yourPlasma: string;
  winner: 'PLASMA' | 'CURRENT' | 'TIE';
}

export interface DevelopmentStatus {
  org: string;
  solution: string;
  cost: string;
  limitation: string;
  performance: string;
}

export interface RealFailure {
  engine: string;
  period?: string;
  problem: string;
  rootCause: string;
  solutionAdopted: string;
  howPlasmaHelps: string;
}

export interface IgniterTiming {
  stage: string;
  time: string;
  basis: string;
}

export interface CarrierGas {
  id: 'argon' | 'hydrogen' | 'argon_h2_80_20' | 'argon_h2_50_50' | 'hydrogen_ar_80_20' | 'helium' | 'xenon' | 'air';
  name: string;
  description: string;
  efficiencyFactor: number; // Multiplier for performance
}

export interface Cathode {
    id: 'tungsten' | 'thoriated_tungsten' | 'lab6' | 'ceb6' | 'scandate' | 'cesiated_tungsten' | 'molybdenum' | 'hafnium' | 'oxide_coated';
    name: string;
    description: string;
    efficiencyFactor: number; // Performance multiplier for this material
}


export interface CryogenicEngine {
  id: string;
  name: string;
  country: string;
  propellants: 'LH2/LOX' | 'CH4/LOX' | 'RP-1/LOX';
  fuel: string;
  oxidizer: string;
  chamberPressure: number; // in MPa
  engineCycle: string;
  baseThrust: number; // in kN
  baseIsp: number; // in s
  dryWeightKg: number; // Dry mass of the engine in kg
  thrustToWeightRatio: number; // TWR at sea level
  diagram: {
    type: 'staged' | 'gas-generator';
    nozzleRatio: number; // Visual cue for nozzle size
  };
}

export interface TestRunDataPoint {
  time: number;
  thrust: number;
  pressure: number;
  plasmaIntensity: number;
}

export interface SimulationOutput {
  thrust: number; // kN
  isp: number; // s
  chamberPressure: number; // MPa
  costEfficiency: number; // Dimensionless score
  plasmaIntensity: number;
}

export interface EngineSpec {
  engine: string;
  country: string;
  propellants: string;
  baseThrust: string;
  enhancedThrust: string;
  thrustGain: string;
  baseISP: string;
  enhancedISP: string;
  ispGain: string;
}
