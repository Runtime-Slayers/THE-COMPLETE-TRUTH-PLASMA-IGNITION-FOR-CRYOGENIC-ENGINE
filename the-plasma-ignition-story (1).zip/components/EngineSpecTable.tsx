import React from 'react';
import type { EngineSpec } from '../types';

interface EngineSpecTableProps {
  specs: EngineSpec[];
}

export const EngineSpecTable = ({ specs }: EngineSpecTableProps) => (
  <div className="bg-brand-surface rounded-lg border border-brand-border shadow-lg overflow-hidden">
    <h3 className="text-xl font-bold text-slate-200 p-4 bg-slate-900/50 flex items-center">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
      COMPLETE ENGINE SPECIFICATIONS & PLASMA ENHANCEMENTS:
    </h3>
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left">
        <thead className="bg-slate-900/50 text-xs text-brand-text-dim uppercase tracking-wider">
          <tr>
            <th scope="col" className="px-6 py-3">Engine</th>
            <th scope="col" className="px-6 py-3">Country</th>
            <th scope="col" className="px-6 py-3">Propellants</th>
            <th scope="col" className="px-6 py-3">Base Thrust</th>
            <th scope="col" className="px-6 py-3">Enhanced Thrust</th>
            <th scope="col" className="px-6 py-3">Thrust Gain</th>
            <th scope="col" className="px-6 py-3">Base ISP</th>
            <th scope="col" className="px-6 py-3">Enhanced ISP</th>
            <th scope="col" className="px-6 py-3">ISP Gain</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-brand-border">
          {specs.map((spec) => (
            <tr key={spec.engine} className="hover:bg-slate-800/50 transition-colors duration-150">
              <th scope="row" className="px-6 py-4 font-bold text-slate-200 whitespace-nowrap">{spec.engine}</th>
              <td className="px-6 py-4 text-brand-text-dim">{spec.country}</td>
              <td className="px-6 py-4 text-brand-text-dim font-mono">{spec.propellants}</td>
              <td className="px-6 py-4 text-brand-text-dim">{spec.baseThrust}</td>
              <td className="px-6 py-4 text-slate-200">{spec.enhancedThrust}</td>
              <td className="px-6 py-4 font-bold text-green-400">{spec.thrustGain}</td>
              <td className="px-6 py-4 text-brand-text-dim">{spec.baseISP}</td>
              <td className="px-6 py-4 text-slate-200">{spec.enhancedISP}</td>
              <td className="px-6 py-4 font-bold text-green-400">{spec.ispGain}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);
