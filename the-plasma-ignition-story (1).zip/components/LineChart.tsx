import React from 'react';
import type { TestRunDataPoint } from '../types';

interface LineChartProps {
  data: TestRunDataPoint[];
  dataKey: 'thrust' | 'pressure' | 'plasmaIntensity';
  label: string;
  color: string;
  width?: number;
  height?: number;
}

export const LineChart = ({ data, dataKey, label, color, width = 300, height = 150 }: LineChartProps) => {
  const padding = 20;
  const chartWidth = width - padding * 2;
  const chartHeight = height - padding * 2;

  const maxValue = Math.max(...data.map(d => d[dataKey]), 1);
  const maxTime = Math.max(...data.map(d => d.time), 1);

  const getX = (time: number) => (time / maxTime) * chartWidth + padding;
  const getY = (value: number) => chartHeight - (value / maxValue) * chartHeight + padding;

  const path = data.map((d, i) => {
    const x = getX(d.time);
    const y = getY(d[dataKey]);
    return `${i === 0 ? 'M' : 'L'} ${x},${y}`;
  }).join(' ');
  
  const lastPoint = data[data.length - 1];
  const lastValue = lastPoint ? lastPoint[dataKey].toFixed(0) : '0';

  return (
    <div className="w-full">
        <h4 className="text-center text-sm text-brand-text-dim">{label}: <span className="font-bold text-slate-200">{lastValue}</span></h4>
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
            {/* Background Lines */}
            <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#334155" strokeWidth="1" />
            <line x1={padding} y1={padding} x2={padding} y2={height - padding} stroke="#334155" strokeWidth="1" />
            
            {/* Data Path */}
            {data.length > 1 && (
                <path d={path} stroke={color} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            )}
        </svg>
    </div>
  );
};