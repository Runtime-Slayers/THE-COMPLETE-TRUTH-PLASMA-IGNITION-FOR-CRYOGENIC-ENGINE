import React from 'react';
import type { CryogenicEngine, CarrierGas, Cathode } from '../types';

const molecules: { [key: string]: React.ReactNode } = {
    // Fuels
    CH4: <g><circle cx="0" cy="0" r="6" fill="#475569" /><circle cx="-5" cy="-5" r="3" fill="#e2e8f0" /><circle cx="5" cy="-5" r="3" fill="#e2e8f0" /><circle cx="-4" cy="5" r="3" fill="#e2e8f0" /><circle cx="4" cy="5" r="3" fill="#e2e8f0" /></g>,
    LH2: <g><circle cx="-4" cy="0" r="3.5" fill="#e2e8f0" /><circle cx="4" cy="0" r="3.5" fill="#e2e8f0" /></g>,
    RP1: <g><rect x="-10" y="-3" width="20" height="6" rx="3" fill="#facc15" opacity="0.8" /><text x="-8" y={2} fill="black" fontSize="5">C₁₂H₂₆</text></g>,
    // Oxidizer
    O2: <g><circle cx="-6" cy="0" r="5" fill="#f43f5e" /><circle cx="6" cy="0" r="5" fill="#f43f5e" /><line x1="-3" y1="0" x2="3" y2="0" stroke="white" strokeWidth="1.5" /></g>,
    O_radical: <g><circle cx="0" cy="0" r="5" fill="#fcd34d" /><text x="-2.5" y={2.5} fontSize="6" fill="black" fontWeight="bold">•</text></g>,
    // Carrier Gases
    Ar: <g><circle cx="0" cy="0" r="6" fill="#818cf8" /><text x="0" y={2} fontSize="7" textAnchor="middle" fill="white" fontWeight="bold">Ar</text></g>,
    H2: <g><circle cx="-4" cy="0" r="3.5" fill="#a5f3fc" /><circle cx="4" cy="0" r="3.5" fill="#a5f3fc" /></g>,
    He: <g><circle cx="0" cy="0" r="5" fill="#fb923c" /><text x="0" y={2} fontSize="6" textAnchor="middle" fill="white" fontWeight="bold">He</text></g>,
    Xe: <g><circle cx="0" cy="0" r="8" fill="#a78bfa" /><text x="0" y={3} fontSize="8" textAnchor="middle" fill="white" fontWeight="bold">Xe</text></g>,
    Air: <g><circle cx="-5" cy="0" r="5" fill="#60a5fa" /><circle cx="5" cy="0" r="5" fill="#60a5fa" /><text x="-5" y={2} fontSize="4" textAnchor="middle" fill="white">N</text><text x="5" y={2} fontSize="4" textAnchor="middle" fill="white">N</text></g>,
    // Other
    Electron: <g><circle cx="0" cy="0" r="3" fill="#38bdf8" /></g>,
    Combustion: <g><path d="M0,-10 L3,-3 L10,0 L3,3 L0,10 L-3,3 L-10,0 L-3,-3 Z" fill="#fef08a"/></g>,
};

const FlowchartStep = ({ title, description, icon, isActive }: { title: string, description: string, icon: React.ReactNode, isActive: boolean }) => (
    <div className={`text-center transition-all duration-300 ${isActive ? 'opacity-100' : 'opacity-40'}`}>
        <div className={`relative w-24 h-24 sm:w-32 sm:h-32 mx-auto bg-brand-surface rounded-full border-2 ${isActive ? 'border-brand-blue-light' : 'border-brand-border'} flex items-center justify-center shadow-lg`}>
            {icon}
        </div>
        <h4 className={`mt-3 font-bold text-sm ${isActive ? 'text-brand-blue-light' : 'text-slate-300'}`}>{title}</h4>
        <p className="text-xs text-brand-text-dim mt-1 max-w-xs mx-auto">{description}</p>
    </div>
);

const Arrow = () => (
    <div className="flex-1 flex items-center justify-center min-w-[2rem] sm:min-w-[4rem]">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-brand-border w-6 h-6 sm:w-8 sm:h-8">
            <path d="M5 12H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 5L19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    </div>
);

interface ChainReactionDiagramProps {
    activeStep: number;
    engine: CryogenicEngine;
    carrierGas: CarrierGas;
    cathode: Cathode;
}

export const ChainReactionDiagram = ({ activeStep, engine, carrierGas, cathode }: ChainReactionDiagramProps) => {
    
    const getFuelMolecule = () => {
        switch (engine.propellants) {
            case 'CH4/LOX': return molecules.CH4;
            case 'LH2/LOX': return molecules.LH2;
            case 'RP-1/LOX': return molecules.RP1;
            default: return molecules.CH4;
        }
    }
    
    const getCarrierMolecule = () => {
        const id = carrierGas.id;
        if (id.includes('argon')) return molecules.Ar;
        if (id.includes('hydrogen')) return molecules.H2;
        if (id.includes('helium')) return molecules.He;
        if (id.includes('xenon')) return molecules.Xe;
        if (id.includes('air')) return molecules.Air;
        return molecules.Ar;
    }

    const steps = [
        { 
            title: "1. Electron Ejection", 
            description: `A high-voltage field extracts a free electron from the ${cathode.name} cathode material.`, 
            icon: <svg viewBox="-20 -20 40 40">
                <rect x="-15" y="-10" width="30" height="20" fill="#475569" />
                <text x="0" y="0" textAnchor="middle" dominantBaseline="middle" fill="#94a3b8" fontSize="6">Cathode</text>
                <g transform="translate(0, -15)">{molecules.Electron}</g>
                <path d="M0 -10 v -3" stroke="#38bdf8" strokeWidth="1" strokeDasharray="1 2"/>
            </svg>
        },
        { 
            title: "2. Impact Ionization Cascade", 
            description: `The electron accelerates, colliding with a neutral ${carrierGas.name.split(' ')[0]} atom and liberating more electrons in an exponential cascade.`, 
            icon: <svg viewBox="-20 -20 40 40">
                <g transform="translate(-15,0)">{molecules.Electron}</g>
                <path d="M-12 0 H -8" stroke="#38bdf8" strokeWidth="1" />
                <g transform="translate(0,0)">{getCarrierMolecule()}</g>
                <text x="0" y="2.5" fontSize="8" textAnchor="middle" fill="#fef08a" fontWeight="bold">+</text>
                <g transform="translate(15, -5)">{molecules.Electron}</g>
                <g transform="translate(15, 5)">{molecules.Electron}</g>
                 <path d="M5 -2 L 12 -5" stroke="#38bdf8" strokeWidth="1" />
                 <path d="M5 2 L 12 5" stroke="#38bdf8" strokeWidth="1" />
            </svg>
        },
        { 
            title: "3. Plasma Kernel Formation", 
            description: "Within microseconds, this cascade forms a dense, high-temperature kernel of ions and electrons—a plasma.", 
            icon: <svg viewBox="-20 -20 40 40">
                <g transform="translate(8, 8)">{molecules.Electron}</g>
                <g transform="translate(-10, 10)">{getCarrierMolecule()}<text x="0" y="2.5" fontSize="8" textAnchor="middle" fill="#fef08a" fontWeight="bold">+</text></g>
                <g transform="translate(-8, -8)">{molecules.Electron}</g>
                <g transform="translate(5, -12)">{molecules.Electron}</g>
                 <g transform="translate(12, -2)">{getCarrierMolecule()}<text x="0" y="2.5" fontSize="8" textAnchor="middle" fill="#fef08a" fontWeight="bold">+</text></g>
            </svg>
        },
        { 
            title: "4. Oxidizer Dissociation", 
            description: `The plasma's intense energy efficiently breaks down stable ${engine.oxidizer} molecules into hyper-reactive oxygen radicals.`, 
            icon: <svg viewBox="-20 -20 40 40">
                <g transform="translate(-10,0)">{molecules.O2}</g>
                <path d="M-2 0 H 3" stroke="#fcd34d" strokeWidth="1.5" strokeDasharray="2 2" />
                <g transform="translate(10, -6)">{molecules.O_radical}</g>
                <g transform="translate(10, 6)">{molecules.O_radical}</g>
            </svg>
        },
        { 
            title: "5. Radical-Initiated Combustion", 
            description: `These radicals instantly initiate a uniform, volumetric combustion reaction with the ${engine.fuel} propellant.`, 
            icon: <svg viewBox="-20 -20 40 40">
                <g transform="translate(-12, 0)">{molecules.O_radical}</g>
                <g transform="translate(12, 0)">{getFuelMolecule()}</g>
                <path d="M-7 0 H 3" stroke="#fef08a" strokeWidth="1" />
                <g transform="scale(1.5)">{molecules.Combustion}</g>
            </svg>
        },
    ];

    return (
        <div className="bg-slate-900/50 p-4 sm:p-6 rounded-lg border border-brand-border">
            <div className="flex flex-col md:flex-row items-stretch justify-between gap-4">
                {steps.map((step, index) => (
                    <React.Fragment key={index}>
                        <FlowchartStep 
                            title={step.title}
                            description={step.description}
                            icon={step.icon}
                            isActive={activeStep >= index + 1}
                        />
                        {index < steps.length - 1 && <Arrow />}
                    </React.Fragment>
                ))}
            </div>
        </div>
    );
};