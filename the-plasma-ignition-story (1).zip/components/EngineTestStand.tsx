import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { ENGINES, CARRIER_GASES, CATHODES } from '../data';
import type { CryogenicEngine, CarrierGas, SimulationOutput, Cathode } from '../types';
import { calculateEnginePerformance } from '../shared/utils';
import { EngineDiagram } from './EngineDiagram';

const getEfficiencyBar = (factor: number, min: number, max: number, size: number = 5) => {
    const range = max - min;
    if (range <= 0) return '░'.repeat(size);
    const filledCount = Math.max(0, Math.min(size, Math.round(((factor - min) / range) * size)));
    return '█'.repeat(filledCount) + '░'.repeat(size - filledCount);
};

const SimulatorControl = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div>
        <label className="block text-sm font-medium text-brand-text-dim mb-2">{label}</label>
        {children}
    </div>
);

const ImprovementIndicator = ({ value }: { value: number }) => {
    if (value === 0) {
        return <span className="text-slate-400">--</span>;
    }
    const isPositive = value > 0;
    return (
        <span className={`font-bold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
            {isPositive ? '▲' : '▼'} {Math.abs(value).toFixed(2)}%
        </span>
    );
};

export const EngineTestStand = ({ onStepChange, activeStep, engine, carrierGas, cathode, onConfigurationChange }: {
    onStepChange: (step: number) => void;
    activeStep: number;
    engine: CryogenicEngine;
    carrierGas: CarrierGas;
    cathode: Cathode;
    onConfigurationChange: (config: { engineId?: string; carrierGasId?: string; cathodeId?: string; }) => void;
}) => {
    const [igniterPower, setIgniterPower] = useState(25); // kW
    const [flowRate, setFlowRate] = useState(100); // %
    const [isFiring, setIsFiring] = useState(false);
    const [baselineActiveStep, setBaselineActiveStep] = useState(-1);
    const stepIntervalRef = useRef<number | null>(null);
    const isFiringRef = useRef(isFiring);

    useEffect(() => {
        isFiringRef.current = isFiring;
    }, [isFiring]);

    const [plasmaOutput, setPlasmaOutput] = useState<SimulationOutput>({ thrust: 0, isp: 0, chamberPressure: 0, costEfficiency: 0, plasmaIntensity: 0 });
    const [baselineOutput, setBaselineOutput] = useState({ thrust: 0, isp: 0, pressure: 0 });

    const minGasFactor = useMemo(() => Math.min(...CARRIER_GASES.map(g => g.efficiencyFactor)), []);
    const maxGasFactor = useMemo(() => Math.max(...CARRIER_GASES.map(g => g.efficiencyFactor)), []);
    const minCathodeFactor = useMemo(() => Math.min(...CATHODES.map(c => c.efficiencyFactor)), []);
    const maxCathodeFactor = useMemo(() => Math.max(...CATHODES.map(c => c.efficiencyFactor)), []);

    const handleFire = useCallback(() => {
        if (isFiring) return;
        setIsFiring(true);
        
        // --- Plasma Engine: Starts ignition sequence immediately ---
        onStepChange(-1); // Reset steps
        let currentStep = 0;
        onStepChange(currentStep);
        stepIntervalRef.current = window.setInterval(() => {
            currentStep++;
            onStepChange(currentStep);
            if (currentStep >= 5) {
                if (stepIntervalRef.current) clearInterval(stepIntervalRef.current);
            }
        }, 300);

        // --- Baseline Engine: Jumps to combustion after a delay ---
        setBaselineActiveStep(-1);
        setTimeout(() => {
            // Only set state if the engine is still supposed to be firing
            if (isFiringRef.current) {
                setBaselineActiveStep(4); // Jump straight to combustion, skipping plasma stages
            }
        }, 2000); // 2000ms ignition delay

    }, [isFiring, onStepChange]);

    const handleShutdown = useCallback(() => {
        setIsFiring(false);
        onStepChange(-1);
        setBaselineActiveStep(-1); // Also reset baseline animation
        if (stepIntervalRef.current) {
            clearInterval(stepIntervalRef.current);
            stepIntervalRef.current = null;
        }
    }, [onStepChange]);

    useEffect(() => {
        if (!isFiring) {
            const zeroOutput = { thrust: 0, isp: 0, chamberPressure: 0, costEfficiency: 0, plasmaIntensity: 0 };
            setPlasmaOutput(zeroOutput);
            setBaselineOutput({ thrust: 0, isp: 0, pressure: 0 });
            return;
        }

        const plasmaPerf = calculateEnginePerformance(engine, igniterPower, flowRate, carrierGas, cathode);
        setPlasmaOutput(plasmaPerf);

        // Calculate baseline performance using NIST-standard data for thermal ignition
        const baseThrust = engine.baseThrust * (flowRate / 100);
        const baseIsp = engine.baseIsp; 
        const basePressure = engine.chamberPressure * (flowRate / 100);
        setBaselineOutput({
            thrust: baseThrust,
            isp: baseIsp,
            pressure: basePressure,
        });

    }, [isFiring, engine, igniterPower, flowRate, carrierGas, cathode]);

    const comparisonData = useMemo(() => {
        const calculateImprovement = (plasma: number, base: number) => {
            if (base === 0) return 0;
            return ((plasma - base) / base) * 100;
        };

        const KN_TO_LBF = 224.809;

        return [
            { metric: 'Thrust Force', unit: 'kN', baseline: baselineOutput.thrust, plasma: plasmaOutput.thrust },
            { metric: 'Thrust Force', unit: 'lbf', baseline: baselineOutput.thrust * KN_TO_LBF, plasma: plasmaOutput.thrust * KN_TO_LBF },
            { metric: 'Specific Impulse (Isp)', unit: 's', baseline: baselineOutput.isp, plasma: plasmaOutput.isp },
            { metric: 'Chamber Pressure', unit: 'MPa', baseline: baselineOutput.pressure, plasma: plasmaOutput.chamberPressure },
        ].map(item => ({
            ...item,
            improvement: calculateImprovement(item.plasma, item.baseline)
        }));
    }, [plasmaOutput, baselineOutput]);

    return (
        <div className="bg-slate-900/50 p-4 sm:p-6 rounded-lg border border-brand-border">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 space-y-4">
                    <h3 className="text-xl font-bold text-slate-200">Test Configuration</h3>
                    
                    <SimulatorControl label="Select Engine Model">
                        <select
                            value={engine.id}
                            onChange={(e) => onConfigurationChange({ engineId: e.target.value })}
                            className="w-full bg-brand-surface border border-brand-border rounded-md p-2 text-brand-text focus:ring-2 focus:ring-brand-blue-light focus:outline-none"
                        >
                            {ENGINES.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                        </select>
                    </SimulatorControl>

                    <SimulatorControl label={`Igniter Power: ${igniterPower.toFixed(1)} kW`}>
                        <input type="range" min="5" max="50" step="0.5" value={igniterPower} onChange={e => setIgniterPower(parseFloat(e.target.value))} className="w-full h-2 bg-brand-border rounded-lg appearance-none cursor-pointer" />
                    </SimulatorControl>

                    <SimulatorControl label={`Propellant Flow: ${flowRate}%`}>
                        <input type="range" min="50" max="100" step="1" value={flowRate} onChange={e => setFlowRate(parseInt(e.target.value, 10))} className="w-full h-2 bg-brand-border rounded-lg appearance-none cursor-pointer" />
                    </SimulatorControl>
                    
                    <SimulatorControl label="Plasma Carrier Gas">
                         <select
                            value={carrierGas.id}
                            onChange={(e) => onConfigurationChange({ carrierGasId: e.target.value })}
                            className="w-full bg-brand-surface border border-brand-border rounded-md p-2 text-brand-text focus:ring-2 focus:ring-brand-blue-light focus:outline-none font-mono"
                        >
                            {CARRIER_GASES.map(g => (
                                <option key={g.id} value={g.id}>
                                    {getEfficiencyBar(g.efficiencyFactor, minGasFactor, maxGasFactor)} {g.name}
                                </option>
                            ))}
                        </select>
                    </SimulatorControl>

                    <SimulatorControl label="Igniter Cathode Material">
                       <select
                            value={cathode.id}
                            onChange={(e) => onConfigurationChange({ cathodeId: e.target.value })}
                            className="w-full bg-brand-surface border border-brand-border rounded-md p-2 text-brand-text focus:ring-2 focus:ring-brand-blue-light focus:outline-none font-mono"
                        >
                            {CATHODES.map(c => (
                                <option key={c.id} value={c.id}>
                                    {getEfficiencyBar(c.efficiencyFactor, minCathodeFactor, maxCathodeFactor)} {c.name}
                                </option>
                            ))}
                        </select>
                    </SimulatorControl>

                    <div className="flex space-x-4 pt-4">
                        <button onClick={handleFire} disabled={isFiring} className="w-full text-center px-4 py-3 bg-green-600 text-white font-bold rounded-md hover:bg-green-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors duration-200">
                            FIRE ENGINE
                        </button>
                        <button onClick={handleShutdown} disabled={!isFiring} className="w-full text-center px-4 py-3 bg-red-600 text-white font-bold rounded-md hover:bg-red-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors duration-200">
                            SHUTDOWN
                        </button>
                    </div>
                </div>

                <div className="lg:col-span-2">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                            <h4 className="text-lg font-bold text-center text-brand-text-dim mb-2">Standard Baseline</h4>
                            <EngineDiagram 
                                engine={engine} 
                                isFiring={isFiring} 
                                thrust={baselineOutput.thrust} 
                                activeStep={baselineActiveStep} 
                                isBaseline={true} 
                            />
                        </div>
                        <div>
                            <h4 className="text-lg font-bold text-center text-brand-blue-light mb-2">⚡️ Plasma Enhanced</h4>
                            <EngineDiagram 
                                engine={engine} 
                                isFiring={isFiring} 
                                thrust={plasmaOutput.thrust} 
                                activeStep={activeStep} 
                            />
                        </div>
                    </div>
                    
                    <div className="bg-brand-surface rounded-lg border border-brand-border overflow-hidden">
                        <h3 className="text-lg font-bold text-slate-200 p-4 bg-slate-900/50">Performance Metrics (NIST Database Model)</h3>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-900/50 text-xs text-brand-text-dim uppercase tracking-wider">
                                    <tr>
                                        <th scope="col" className="px-4 py-3">Metric</th>
                                        <th scope="col" className="px-4 py-3 text-right">Baseline</th>
                                        <th scope="col" className="px-4 py-3 text-right">Plasma</th>
                                        <th scope="col" className="px-4 py-3 text-right">Improvement</th>
                                    </tr>
                                </thead>
                                <tbody className="font-mono">
                                    {comparisonData.map((row, index) => (
                                        <tr key={index} className="border-t border-brand-border">
                                            <th scope="row" className="px-4 py-3 font-medium text-slate-300 whitespace-nowrap">{row.metric} <span className="text-xs text-brand-text-dim">({row.unit})</span></th>
                                            <td className="px-4 py-3 text-right text-brand-text-dim">{row.baseline.toFixed(2)}</td>
                                            <td className="px-4 py-3 text-right text-slate-200 font-bold">{row.plasma.toFixed(2)}</td>
                                            <td className="px-4 py-3 text-right"><ImprovementIndicator value={row.improvement} /></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};