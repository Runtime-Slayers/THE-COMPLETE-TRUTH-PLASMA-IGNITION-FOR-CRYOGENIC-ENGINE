import React from 'react';

const SubSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <div className="mb-6">
        <h4 className="text-lg font-semibold text-slate-300 mb-2">{title}</h4>
        {children}
    </div>
);


const PropulsionFlowchart = () => (
     <div className="flex justify-center my-8">
        <svg viewBox="0 0 900 500" className="w-full max-w-5xl h-auto">
            <defs>
                <style>{`
                    .flow-line { stroke-dasharray: 1000; stroke-dashoffset: 1000; animation: draw-line 2s ease-out forwards; }
                    .flow-node { opacity: 0; animation: fade-in 0.8s ease-out forwards; }
                    @keyframes draw-line { to { stroke-dashoffset: 0; } }
                    @keyframes fade-in { to { opacity: 1; } }
                `}</style>
                 <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                    <feMerge>
                        <feMergeNode in="coloredBlur" />
                        <feMergeNode in="SourceGraphic" />
                    </feMerge>
                </filter>
            </defs>

            {/* Nodes */}
            {/* Level 1 */}
            <g className="flow-node" style={{ animationDelay: '0s' }}>
                <rect x="350" y="10" width="200" height="40" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="450" y="32" textAnchor="middle" fill="#e2e8f0" fontWeight="bold">Rocket Propulsion</text>
            </g>

            {/* Level 2 */}
            <g className="flow-node" style={{ animationDelay: '0.5s' }}>
                <rect x="125" y="120" width="150" height="40" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="200" y="142" textAnchor="middle" fill="#e2e8f0" fontWeight="bold">Chemical</text>
            </g>
            <g className="flow-node" style={{ animationDelay: '0.6s' }}>
                <rect x="375" y="120" width="150" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="450" y="142" textAnchor="middle" fill="#94a3b8">Electric</text>
            </g>
            <g className="flow-node" style={{ animationDelay: '0.7s' }}>
                <rect x="625" y="120" width="150" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="700" y="142" textAnchor="middle" fill="#94a3b8">Nuclear</text>
            </g>

            {/* Level 3 */}
            {/* Chemical Children */}
            <g className="flow-node" style={{ animationDelay: '1.0s' }}>
                <rect x="50" y="230" width="100" height="40" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="100" y="252" textAnchor="middle" fill="#e2e8f0" fontWeight="bold">Liquid</text>
            </g>
            <g className="flow-node" style={{ animationDelay: '1.1s' }}>
                <rect x="175" y="230" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="225" y="252" textAnchor="middle" fill="#94a3b8">Solid</text>
            </g>
            <g className="flow-node" style={{ animationDelay: '1.2s' }}>
                <rect x="300" y="230" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="350" y="252" textAnchor="middle" fill="#94a3b8">Hybrid</text>
            </g>
            {/* Electric Children */}
            <g className="flow-node" style={{ animationDelay: '1.3s' }}>
                <rect x="425" y="230" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="475" y="252" textAnchor="middle" fill="#94a3b8" fontSize="11">Ion Thruster</text>
            </g>
            <g className="flow-node" style={{ animationDelay: '1.4s' }}>
                <rect x="550" y="230" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="600" y="252" textAnchor="middle" fill="#94a3b8" fontSize="11">Hall-Effect</text>
            </g>
            {/* Nuclear Children */}
            <g className="flow-node" style={{ animationDelay: '1.5s' }}>
                <rect x="675" y="230" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="725" y="252" textAnchor="middle" fill="#94a3b8" fontSize="11">Thermal</text>
            </g>
             <g className="flow-node" style={{ animationDelay: '1.6s' }}>
                <rect x="800" y="230" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="850" y="252" textAnchor="middle" fill="#94a3b8" fontSize="11">Electric</text>
            </g>

            {/* Level 4 */}
            <g className="flow-node" style={{ animationDelay: '1.8s' }}>
                <rect x="50" y="340" width="100" height="40" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" filter="url(#glow)"/>
                <text x="100" y="362" textAnchor="middle" fill="#e2e8f0" fontWeight="bold">Cryogenic</text>
            </g>
            <g className="flow-node" style={{ animationDelay: '1.9s' }}>
                <rect x="175" y="340" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="225" y="362" textAnchor="middle" fill="#94a3b8">Bipropellant</text>
            </g>
            <g className="flow-node" style={{ animationDelay: '2.0s' }}>
                <rect x="300" y="340" width="100" height="40" rx="5" fill="#0f172a" stroke="#94a3b8" strokeWidth="1" />
                <text x="350" y="362" textAnchor="middle" fill="#94a3b8">Monopropellant</text>
            </g>

            {/* --- Lines --- */}
            <path d="M450 50 V 85" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.2s' }}/>
            <path d="M200 85 H 700" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.2s' }}/>
            <path d="M200 85 V 120" fill="none" stroke="#38bdf8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.3s' }}/>
            <path d="M450 85 V 120" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.4s' }}/>
            <path d="M700 85 V 120" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.5s' }}/>
            
            {/* L2 to L3 Connectors */}
            {/* Chemical */}
            <path d="M200 160 V 195" fill="none" stroke="#38bdf8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.8s' }}/>
            <path d="M100 195 H 350" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.8s' }}/>
            <path d="M100 195 V 230" fill="none" stroke="#38bdf8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.9s' }}/>
            <path d="M225 195 V 230" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.0s' }}/>
            <path d="M350 195 V 230" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.1s' }}/>
            
            {/* Electric */}
            <path d="M450 160 V 195" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.8s' }}/>
            <path d="M475 195 H 600" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.8s' }}/>
            <path d="M475 195 V 230" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.2s' }}/>
            <path d="M600 195 V 230" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.3s' }}/>

            {/* Nuclear */}
            <path d="M700 160 V 195" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.8s' }}/>
            <path d="M725 195 H 850" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '0.8s' }}/>
            <path d="M725 195 V 230" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.4s' }}/>
            <path d="M850 195 V 230" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.5s' }}/>

            {/* L3 to L4 Connectors */}
            {/* Liquid */}
            <path d="M100 270 V 305" fill="none" stroke="#38bdf8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.6s' }}/>
            <path d="M100 305 H 350" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.6s' }}/>
            <path d="M100 305 V 340" fill="none" stroke="#38bdf8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.7s' }}/>
            <path d="M225 305 V 340" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.8s' }}/>
            <path d="M350 305 V 340" fill="none" stroke="#94a3b8" strokeWidth="1.5" className="flow-line" style={{ animationDelay: '1.9s' }}/>
        </svg>
    </div>
);


export const PropulsionPrimer = () => (
    <div className="space-y-8 text-brand-text-dim leading-relaxed">
        <p>
            Rocket engines create thrust by expelling mass at high velocity, based on Newton's Third Law. They are broadly classified into three main categories based on the type of propellant and energy source they use. The following flowchart illustrates this hierarchy, highlighting the path to the high-performance engines that are the focus of our analysis.
        </p>
       
        <PropulsionFlowchart />

        <div>
            <h3 className="text-xl font-bold text-slate-200 mb-4 border-b border-brand-border pb-2">Categories of Rocket Engines</h3>
            <p className="mb-4">
                Rocket engines can be broadly classified into three main categories based on the type of propellant they use: chemical, electric, and nuclear.
            </p>
        </div>

        <div>
            <h3 className="text-xl font-bold text-slate-200 mb-4 border-b border-brand-border pb-2">1. Chemical Rockets</h3>
            <p className="mb-4">
                These engines create thrust by burning chemical propellants to produce hot exhaust gases. They are the most common type used for launching rockets off the ground and for high-thrust maneuvers. This category is further subdivided by the state of the propellant:
            </p>
            <div className="pl-4 space-y-4">
                <SubSection title="Solid-Propellant Rockets">
                    <p>The fuel and oxidizer are mixed into a solid block, called a grain. They are simple and reliable, but once ignited, they cannot be shut off or controlled. They are often used as boosters.</p>
                </SubSection>
                <SubSection title="Liquid-Propellant Rockets">
                    <p>The fuel and oxidizer are stored separately in liquid form and pumped into a combustion chamber. This allows for throttling (varying thrust) and restarting the engine. The Vikas engine is a type of liquid-fueled chemical rocket engine. It is a family of <strong className="text-slate-300">hypergolic</strong> engines, meaning its fuel (Unsymmetrical Dimethylhydrazine or UDMH) and oxidizer (Nitrogen Tetroxide or N2O4) ignite spontaneously upon contact.</p>
                    <ul className="list-disc list-inside mt-2 pl-2 space-y-1">
                        <li><strong className="text-slate-300">Bipropellant:</strong> Uses separate liquid fuel and oxidizer, like the Vikas engine.</li>
                        <li><strong className="text-slate-300">Monopropellant:</strong> Uses a single liquid propellant that decomposes to produce thrust.</li>
                        <li><strong className="text-slate-300">Cryogenic:</strong> Uses liquid propellants that must be stored at extremely low temperatures, such as liquid hydrogen and liquid oxygen.</li>
                    </ul>
                </SubSection>
                 <SubSection title="Hybrid-Propellant Rockets">
                    <p>Use a combination of a solid fuel and a liquid oxidizer.</p>
                </SubSection>
            </div>
        </div>
        
        <div>
            <h3 className="text-xl font-bold text-slate-200 mb-4 border-b border-brand-border pb-2">2. Electric Rockets</h3>
            <p>
                These engines use electricity to accelerate a propellant to extremely high speeds, resulting in very high efficiency but very low thrust. They are best suited for long-duration missions in space, such as satellite station-keeping and deep-space probes. Types include Ion thrusters and Hall-effect thrusters.
            </p>
        </div>

        <div>
            <h3 className="text-xl font-bold text-slate-200 mb-4 border-b border-brand-border pb-2">3. Nuclear Rockets</h3>
            <p>
                These rockets derive their power from a nuclear reactor. They offer a higher efficiency than chemical rockets but are still in the developmental or experimental stage. Types include Nuclear thermal engines and Nuclear electric propulsion.
            </p>
        </div>

        <div className="p-4 bg-brand-surface border-l-4 border-brand-blue rounded-r-lg">
             <h3 className="text-xl font-bold text-slate-200 mb-2">Our Focus: The Cryogenic Ignition Problem</h3>
             <p>This analysis and simulation centers on the most powerful and efficient class of chemical engines: <strong className="text-brand-blue-light">Liquid-Propellant Cryogenic Engines</strong>. Their high performance comes with a critical vulnerability—the immense difficulty of reliably igniting their super-cooled propellants. The following sections explore this challenge and present plasma ignition as the definitive solution.</p>
        </div>
    </div>
);