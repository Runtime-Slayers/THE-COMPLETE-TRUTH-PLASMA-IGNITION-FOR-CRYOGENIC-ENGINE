import React from 'react';
import type { CryogenicEngine } from '../types';

const SvgText = ({ x, y, children, ...props }: { x: number; y: number; children: React.ReactNode; [key: string]: any }) => (
    <text
        x={x}
        y={y}
        textAnchor="middle"
        dominantBaseline="middle"
        fill="#e2e8f0"
        paintOrder="stroke"
        stroke="#020617"
        strokeWidth={4}
        strokeLinecap="butt"
        strokeLinejoin="miter"
        style={{ fontSize: '12px', fontWeight: 'bold', pointerEvents: 'none' }}
        {...props}
    >
        {children}
    </text>
);

const getPropellantInfo = (propellants: CryogenicEngine['propellants']) => {
    switch (propellants) {
        case 'LH2/LOX': return { fuel: 'LIQUID H2', oxidizer: 'LIQUID O2', fuelColor: '#a5f3fc', oxColor: '#f97316' };
        case 'CH4/LOX': return { fuel: 'LIQUID CH4', oxidizer: 'LIQUID O2', fuelColor: '#38bdf8', oxColor: '#f97316' };
        case 'RP-1/LOX': return { fuel: 'RP-1 KEROSENE', oxidizer: 'LIQUID O2', fuelColor: '#facc15', oxColor: '#f97316' };
        default: return { fuel: 'FUEL', oxidizer: 'OXIDIZER', fuelColor: '#38bdf8', oxColor: '#f97316' };
    }
};

const getPhaseColors = (step: number) => {
    // step is 0-indexed (-1 for off)
    const colors = {
        igniterFill: 'transparent',
        chamberFill: '#475569',
        nozzleFill: '#475569',
    };

    if (step >= 0 && step < 2) { // Electron Gen & Impact Ionization
        colors.igniterFill = '#38bdf8';
    }
    if (step >= 2 && step < 4) { // Plasma Formation & Bond Breaking
        colors.igniterFill = '#38bdf8';
        colors.chamberFill = '#4c1d95'; // Deep purple for plasma
    }
    if (step >= 4) { // Hyper-Combustion
        colors.igniterFill = '#fbbf24';
        colors.chamberFill = '#f97316'; // Bright orange for combustion
        colors.nozzleFill = '#dc2626'; // Red hot nozzle
    }
    return colors;
};


const TestStandDiagram = ({ engine, isFiring, activeStep, isBaseline = false }: { engine: CryogenicEngine; isFiring: boolean; activeStep: number; isBaseline?: boolean; }) => {
    const { fuel, oxidizer, fuelColor, oxColor } = getPropellantInfo(engine.propellants);
    const { igniterFill, chamberFill, nozzleFill } = getPhaseColors(activeStep);
    
    // Increased nozzle length for better proportions
    const nozzleLength = 300; 
    const nozzleExitWidth = 160;

    return (
        <svg viewBox="0 0 400 600" className="w-full h-auto">
            <defs>
                <linearGradient id="regenGradient" gradientUnits="userSpaceOnUse" x1="200" y1={280 + nozzleLength} x2="200" y2="205">
                    <stop offset="0%" stopColor={fuelColor} />
                    <stop offset="100%" stopColor="#f59e0b" />
                </linearGradient>
                <style>{`
                    .flow-line { stroke-dasharray: 8; stroke-dashoffset: 16; animation: dash 0.8s linear infinite; }
                    @keyframes dash { to { stroke-dashoffset: 0; } }
                    .combustion-flicker { animation: flicker 0.1s ease-in-out infinite alternate; }
                    @keyframes flicker {
                        from { opacity: 0.8; transform: scale(1); }
                        to { opacity: 1; transform: scale(1.02); }
                    }
                `}</style>
                <filter id="glow">
                    <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
                    <feMerge>
                        <feMergeNode in="coloredBlur" />
                        <feMergeNode in="SourceGraphic" />
                    </feMerge>
                </filter>
            </defs>

            {/* PROPULSION SYSTEM */}
            <g id="tanks">
                <rect x={40} y={20} width={140} height={70} rx={8} fill="#1e293b" stroke={fuelColor} strokeWidth="2" />
                <SvgText x={110} y={55}>LIQUID {fuel.split(' ')[1]} TANK</SvgText>
                
                <rect x={220} y={20} width={140} height={70} rx={8} fill="#1e293b" stroke={oxColor} strokeWidth="2" />
                <SvgText x={290} y={55}>LIQUID O2 TANK</SvgText>
            </g>

            <g id="feed-system" strokeWidth="2.5">
                {/* Pipes */}
                <path d="M110 90 V 125" fill="none" stroke="#64748b" />
                <path d="M290 90 V 125" fill="none" stroke="#64748b" />
                <path d="M110 145 V 170 H 180" fill="none" stroke="#64748b" />
                <path d="M290 145 V 170 H 220" fill="none" stroke="#64748b" />
                
                {/* Animated Flow */}
                {isFiring && <path d="M110 90 V 125" fill="none" stroke={fuelColor} className="flow-line" />}
                {isFiring && <path d="M290 90 V 125" fill="none" stroke={oxColor} className="flow-line" />}
                {isFiring && <path d="M110 145 V 170 H 180" fill="none" stroke={fuelColor} className="flow-line" />}
                {isFiring && <path d="M290 145 V 170 H 220" fill="none" stroke={oxColor} className="flow-line" />}

                {/* Pumps */}
                <circle cx={110} cy={135} r={10} fill="#334155" stroke="#94a3b8" />
                <SvgText x={60} y={135} style={{fontSize: '10px'}}>FUEL PUMP</SvgText>
                <circle cx={290} cy={135} r={10} fill="#334155" stroke="#94a3b8" />
                <SvgText x={340} y={135} style={{fontSize: '10px'}}>OX PUMP</SvgText>

                {/* Engine Cycle Label */}
                <g>
                    <path d="M 160 135 H 240" stroke="#94a3b8" strokeWidth="1" strokeDasharray="2 2" />
                    <SvgText x={200} y={125} style={{fontSize: '10px', fill: '#94a3b8'}}>{engine.engineCycle}</SvgText>
                </g>
            </g>
            
            <g id="engine-assembly">
                {/* Control Valves */}
                <rect x={160} y={170} width={80} height={15} fill="#475569" />
                <SvgText x={200} y={165} style={{fontSize: '10px'}}>CONTROL VALVES</SvgText>

                {/* Main Injector */}
                <rect x={140} y={185} width={120} height={20} fill="#64748b" />
                <SvgText x={200} y={195}>MAIN INJECTOR</SvgText>

                {/* Combustion Chamber */}
                <path d="M130 205 L 120 280 H 280 L 270 205 Z" fill={chamberFill} stroke="#94a3b8" strokeWidth="1.5" style={{ transition: 'fill 0.3s ease-in-out' }} />
                <SvgText x={200} y={245}>COMBUSTION CHAMBER</SvgText>

                {/* Igniter */}
                <path d="M190 205 L 210 205 L 205 215 L 195 215 Z" fill={igniterFill} stroke="#a5f3fc" strokeWidth="1.5" style={{ transition: 'fill 0.3s ease-in-out' }} />
                <SvgText x={200} y={225} style={{fontSize: '10px'}}>{isBaseline ? 'STANDARD IGNITER' : 'PLASMA IGNITER'}</SvgText>
                
                {/* Regenerative Cooling */}
                <g id="regenerative-cooling">
                    {/* The gradient makes these pipes distinct from other fuel lines, showing temperature change. */}
                    <path d={`M ${200 - nozzleExitWidth / 2 - 4} ${280 + nozzleLength} C 106 350, 146 300, 156 280 L 116 280 L 126 205`} fill="none" stroke="url(#regenGradient)" strokeWidth="3" />
                    <path d={`M ${200 + nozzleExitWidth / 2 + 4} ${280 + nozzleLength} C 294 350, 254 300, 244 280 L 284 280 L 274 205`} fill="none" stroke="url(#regenGradient)" strokeWidth="3" />

                    <SvgText x={90} y={220} style={{ fill: fuelColor, fontSize: '10px', textAnchor: 'end' }}>REGEN. COOLING</SvgText>
                    <path d="M88 220 L 124 210" stroke={fuelColor} strokeWidth="1" opacity="0.8" />
                </g>

                {/* Nozzle */}
                <path d={`M 160 280 C 150 300, 110 350, ${200 - nozzleExitWidth/2} ${280 + nozzleLength} L ${200 + nozzleExitWidth/2} ${280 + nozzleLength} C 290 350, 250 300, 240 280 Z`} fill={nozzleFill} stroke="#94a3b8" strokeWidth="1.5" style={{ transition: 'fill 0.3s ease-in-out' }}/>
                <SvgText x={200} y={295}>THROAT</SvgText>
                <SvgText x={200} y={430}>NOZZLE</SvgText>
            </g>
            
            {isFiring && activeStep >= 4 && (
                <g className="combustion-flicker" transform="translate(200 245)" transform-origin="center">
                    <circle cx={0} cy={0} r={30} fill="#fef08a" filter="url(#glow)" />
                    <circle cx={0} cy={0} r={15} fill="white" />
                </g>
            )}

        </svg>
    );
};


export const EngineDiagram = ({ engine, isFiring, thrust, activeStep, isBaseline = false }: { engine: CryogenicEngine | null; isFiring: boolean; thrust: number; activeStep: number; isBaseline?: boolean; }) => {
    if (!engine) {
        return <div className="w-full min-h-[450px] lg:min-h-[600px] bg-slate-950 rounded-md flex items-center justify-center text-brand-text-dim">Select an engine to begin</div>;
    }
    
    const thrustScale = Math.min(1, thrust / 10000);
    const plumeLength = isFiring ? 300 + 250 * thrustScale : 0;
    const plumeWidth = isFiring ? 80 + 80 * thrustScale : 0;
    const plumeOpacity = isFiring ? Math.max(0.2, thrustScale * 0.95) : 0;
    
    const nozzleThroatY = 280;

    return (
        <div className="relative w-full max-w-sm mx-auto min-h-[450px] lg:min-h-[600px]">
            <TestStandDiagram engine={engine} isFiring={isFiring} activeStep={activeStep} isBaseline={isBaseline} />
            
            <svg viewBox="0 0 400 600" className="w-full h-auto absolute top-0 left-0 pointer-events-none">
                <defs>
                    <linearGradient id="plumeGradient" x1="0.5" y1="0" x2="0.5" y2="1">
                        <stop offset="0%" stopColor="#fde047" />
                        <stop offset="20%" stopColor="#fef08a" />
                        <stop offset="60%" stopColor="#f97316" />
                        <stop offset="100%" stopColor="#dc2626" stopOpacity={0.5} />
                    </linearGradient>
                    <filter id="plumeGlow">
                        <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                </defs>
                {/* Mach diamonds */}
                {isFiring && thrustScale > 0.5 && Array.from({ length: Math.floor(thrustScale * 4) }).map((_, i) => (
                    <ellipse
                        key={i}
                        cx={200}
                        cy={nozzleThroatY + 40 + i * 50}
                        rx={Math.max(0, (plumeWidth / 2.5) * (1 - (i / (thrustScale * 4))))}
                        ry={20}
                        fill="#a5f3fc"
                        opacity={plumeOpacity * 0.5 * (1 - (i / (thrustScale * 5)))}
                        style={{ transition: 'all 0.3s ease-out' }}
                    />
                ))}
                <path 
                    d={`M 200 ${nozzleThroatY} C ${200 - plumeWidth / 2} ${nozzleThroatY + plumeLength * 0.4}, ${200 - plumeWidth / 1.5} ${nozzleThroatY + plumeLength * 0.7}, 200 ${nozzleThroatY + plumeLength} C ${200 + plumeWidth / 1.5} ${nozzleThroatY + plumeLength * 0.7}, ${200 + plumeWidth / 2} ${nozzleThroatY + plumeLength * 0.4}, 200 ${nozzleThroatY}`}
                    fill="url(#plumeGradient)" 
                    opacity={plumeOpacity}
                    style={{ transition: 'all 0.3s ease-out', filter: 'url(#plumeGlow)' }}
                />
            </svg>
        </div>
    );
};