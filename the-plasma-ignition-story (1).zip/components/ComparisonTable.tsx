import React from 'react';
import type { ComparisonMetric } from '../types';

interface ComparisonTableProps {
  title: string;
  data: ComparisonMetric[];
}

const WinnerIcon = ({ winner }: { winner: 'PLASMA' | 'CURRENT' | 'TIE' }) => {
    switch (winner) {
        case 'PLASMA':
            return <span className="text-brand-blue-light font-bold flex items-center">⚡️ PLASMA</span>;
        case 'CURRENT':
            return <span className="text-yellow-400 font-bold flex items-center">🔥 CURRENT</span>;
        case 'TIE':
            return <span className="text-slate-400 font-bold flex items-center">🤝 TIE</span>;
        default:
            return null;
    }
}

export const ComparisonTable = ({ title, data }: ComparisonTableProps) => (
  <div className="bg-brand-surface rounded-lg border border-brand-border shadow-lg overflow-hidden">
    <h3 className="text-xl font-bold text-slate-200 p-4 bg-slate-900/50">{title}</h3>
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left">
        <thead className="bg-slate-900/50 text-xs text-brand-text-dim uppercase tracking-wider">
          <tr>
            <th scope="col" className="px-6 py-3">Metric</th>
            <th scope="col" className="px-6 py-3">Best Current System</th>
            <th scope="col" className="px-6 py-3">Your Plasma Solution</th>
            <th scope="col" className="px-6 py-3">Winner</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row.metric} className="border-t border-brand-border">
              <th scope="row" className="px-6 py-4 font-medium text-slate-200 whitespace-nowrap">{row.metric}</th>
              <td className="px-6 py-4 text-brand-text-dim">{row.bestCurrent}</td>
              <td className="px-6 py-4 text-brand-text-dim">{row.yourPlasma}</td>
              <td className="px-6 py-4"><WinnerIcon winner={row.winner} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);
