import React from 'react';
import type { CryogenicEngine, CarrierGas, Cathode } from '../types';

const SvgText = ({ x, y, children, ...props }: { x: number; y: number; children: React.ReactNode; [key: string]: any }) => (
    <text
        x={x}
        y={y}
        fill="#94a3b8"
        style={{ fontSize: '11px', pointerEvents: 'none' }}
        {...props}
    >
        {children}
    </text>
);

const getShortName = (name: string) => {
    const parts = name.split(' ');
    if (parts.length > 1) {
        if (parts[1].startsWith('(')) return parts[0];
        return parts[1];
    }
    return name;
}

interface IgniterDiagramExplainedProps {
    engine: CryogenicEngine;
    carrierGas: CarrierGas;
    cathode: Cathode;
}

export const IgniterDiagramExplained = ({ engine, carrierGas, cathode }: IgniterDiagramExplainedProps) => (
    <div className="bg-brand-surface p-6 rounded-lg border border-brand-border shadow-lg">
        <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="w-full lg:w-2/3">
                <svg viewBox="0 0 500 400" className="w-full h-auto">
                    <defs>
                        <linearGradient id="plasma-gradient" gradientTransform="rotate(90)">
                            <stop offset="0%" stopColor="#a5f3fc" stopOpacity="0.8" />
                            <stop offset="100%" stopColor="#0ea5e9" />
                        </linearGradient>
                        <filter id="plasma-glow" x="-50%" y="-50%" width="200%" height="200%">
                            <feGaussianBlur stdDeviation="10" result="coloredBlur" />
                            <feMerge>
                                <feMergeNode in="coloredBlur" />
                                <feMergeNode in="SourceGraphic" />
                            </feMerge>
                        </filter>
                        <style>{`
                            @keyframes plasma-flicker {
                                0%, 100% { opacity: 0.9; transform: scaleY(1); }
                                50% { opacity: 1; transform: scaleY(1.03); }
                            }
                            .plasma-jet {
                                animation: plasma-flicker 1.5s ease-in-out infinite;
                                transform-origin: center;
                            }
                        `}</style>
                    </defs>

                    {/* Main Engine Integration (background) */}
                    <path d="M150 280 H 350 L 380 400 H 120 Z" fill="#1e293b" opacity="0.5" />
                    <SvgText x={250} y={320} textAnchor="middle" fill="#e2e8f0">MAIN COMBUSTION CHAMBER</SvgText>

                    {/* Plasma Igniter Body */}
                    <g id="igniter-body">
                        <path d="M180 50 L 320 50 Q 330 50 330 60 L 330 250 H 170 L 170 60 Q 170 50 180 50 Z" fill="#475569" stroke="#94a3b8" strokeWidth="1.5" />
                        <rect x={170} y={250} width={160} height={15} fill="#334155" stroke="#94a3b8" strokeWidth="1.5" />
                        <SvgText x={250} y={40} textAnchor="middle">Anode Electrode (Grounded)</SvgText>
                        <rect x={210} y={60} width={80} height={150} fill="#cbd5e1" opacity="0.2" />
                        <path d="M300 130 H 340" stroke="#94a3b8" strokeWidth="1" />
                        <SvgText x={345} y={130} textAnchor="start">Ceramic Lining</SvgText>
                    </g>
                    
                    {/* Electrodes & Power */}
                    <g>
                        <rect x={240} y={60} width={20} height={150} rx={2} fill="#1e293b" stroke="#64748b" />
                        <path d="M250 60 V 20 H 450" fill="none" stroke="#facc15" strokeWidth="2" strokeDasharray="4 4"/>
                        <SvgText x={400} y={15} fill="#facc15">High-Voltage Power (~3kV)</SvgText>
                        <SvgText x={250} y={225} textAnchor="middle">{cathode.name} Cathode (-)</SvgText>
                    </g>

                    {/* Gas Inlets */}
                    <g id="gas-injection">
                        {/* Carrier Gas */}
                        <path d="M20 100 H 175 C 190 100 190 120 175 120 H 170" fill="none" stroke="#38bdf8" strokeWidth="2" />
                        <SvgText x={25} y={95} fill="#38bdf8">{`Carrier Gas (${getShortName(carrierGas.name)}) - Tangential Inlet`}</SvgText>
                        
                        {/* Fuel */}
                        <path d="M20 160 H 220 V 200" fill="none" stroke="#f97316" strokeWidth="2" />
                        <SvgText x={25} y={155} fill="#f97316">{`Fuel (${getShortName(engine.fuel)}) - Axial Inlet`}</SvgText>

                        {/* Oxidizer */}
                        <path d="M480 180 H 310 V 200" fill="none" stroke="#fbbf24" strokeWidth="2" />
                        <SvgText x={475} y={175} textAnchor="end" fill="#fbbf24">{`Oxidizer (${getShortName(engine.oxidizer)}) Inlet`}</SvgText>
                    </g>

                    {/* Plasma Discharge */}
                    <g id="plasma-discharge" className="plasma-jet">
                        <path d="M 250 210 Q 230 240 250 290 Q 270 240 250 210 Z" fill="url(#plasma-gradient)" filter="url(#plasma-glow)" />
                        <text x={250} y={255} textAnchor="middle" dominantBaseline="middle" pointerEvents="none">
                            <tspan fill="white" fontWeight="bold" fontSize="14" stroke="#020617" strokeWidth={2}>PLASMA</tspan>
                            <tspan x={250} dy="1.2em" fill="white" fontSize="11">(~15,000K)</tspan>
                        </text>
                    </g>
                     <SvgText x={250} y={380} textAnchor="middle" fill="white" style={{fontWeight:'bold'}}>Enhanced Combustion Zone</SvgText>

                </svg>
            </div>
            <div className="w-full lg:w-1/3 space-y-4">
                <h3 className="text-xl font-bold text-slate-200">System Breakdown</h3>
                <div>
                    <h4 className="font-bold text-brand-blue-light">1. Vortex-Confined Arc</h4>
                    <p className="text-sm text-brand-text-dim">An inert carrier gas is injected tangentially, creating a strong vortex. This vortex uses centripetal force to stabilize and confine the high-voltage plasma arc to the igniter's centerline, preventing wall contact and dramatically increasing thermal efficiency and component lifespan.</p>
                </div>
                <div>
                    <h4 className="font-bold text-brand-blue-light">2. Non-Thermal Plasma Generation</h4>
                    <p className="text-sm text-brand-text-dim">A high-voltage, low-current discharge from the advanced cathode material ionizes the carrier gas. This efficiently creates a non-thermal (or "cold") plasma, where electrons have extremely high kinetic energy (~15,000K) while heavier ions and neutral particles remain relatively cool. This is key to its low power consumption.</p>
                </div>
                 <div>
                    <h4 className="font-bold text-brand-blue-light">3. Energy-Efficient Dissociation</h4>
                    <p className="text-sm text-brand-text-dim">The hyper-energetic free electrons in the plasma jet are perfectly suited to break the strong covalent bonds of propellant molecules (e.g., O=O) through direct kinetic impact. This process of dissociation is far more energy-efficient than brute-force thermal heating used by conventional systems.</p>
                </div>
                <div>
                    <h4 className="font-bold text-brand-blue-light">4. Volumetric Radical Seeding</h4>
                    <p className="text-sm text-brand-text-dim">The output is not just heat; it's a high-velocity jet saturated with hyper-reactive radicals (like O•). This jet permeates the main injector face, "seeding" the entire propellant volume. This ensures combustion begins everywhere simultaneously, eliminating ignition delays and preventing combustion instability.</p>
                </div>
            </div>
        </div>
    </div>
);