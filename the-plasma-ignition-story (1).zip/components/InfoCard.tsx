import React from 'react';

interface InfoCardProps {
  title: string;
  items: string[];
}

export const InfoCard = ({ title, items }: InfoCardProps) => (
  <div className="bg-brand-surface p-6 rounded-lg border border-brand-border h-full shadow-lg">
    <h4 className="font-bold text-lg text-brand-blue-light mb-3">{title}</h4>
    <ul className="space-y-2">
      {items.map((item, index) => (
        <li key={index} className="text-sm text-brand-text-dim leading-relaxed">
          {item}
        </li>
      ))}
    </ul>
  </div>
);
