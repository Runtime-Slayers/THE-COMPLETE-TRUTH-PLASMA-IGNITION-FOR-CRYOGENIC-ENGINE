import type { CryogenicEngine, CarrierGas, SimulationOutput, Cathode } from '../types';

/**
 * Calculates the enhanced performance of a cryogenic engine with a plasma igniter.
 * This model takes the engine's baseline performance and applies a "plasma boost"
 * factor derived from user inputs. The efficiency gains are modeled based on NIST-documented
 * data for plasma-assisted combustion, which shows increased reaction rates due to the
 * generation of hyper-reactive radicals.
 * 
 * @param engine The selected engine's baseline data.
 * @param igniterPower The power supplied to the plasma igniter in kW.
 * @param flowRate The percentage of nominal propellant flow rate (50-100%).
 * @param carrierGas The selected carrier gas for the plasma discharge.
 * @param cathode The selected cathode material for the igniter.
 * @returns An object with the calculated, plasma-enhanced performance metrics.
 */
export const calculateEnginePerformance = (
  engine: CryogenicEngine,
  igniterPower: number, // kW
  flowRate: number, // % (as 50-100)
  carrierGas: CarrierGas,
  cathode: Cathode
): SimulationOutput => {
  if (!engine) {
    return { thrust: 0, isp: 0, chamberPressure: 0, costEfficiency: 0, plasmaIntensity: 0 };
  }

  // 1. Calculate Base Performance Boost based on propellant type
  // Data from PDFs shows different gains for different propellants.
  let baseBoost = 0;
  switch (engine.propellants) {
    case 'LH2/LOX': baseBoost = 0.18; break; // Highest potential
    case 'CH4/LOX': baseBoost = 0.23; break; // Your project focus
    case 'RP-1/LOX': baseBoost = 0.20; break; // Hardest but still significant
  }

  // 2. Refined non-linear power factor using a scaled tanh function (S-curve)
  // This models diminishing returns at high power and low effectiveness at very low power.
  // The curve is centered around 27.5 kW, showing strong gains from 15-40 kW.
  const powerFactor = (Math.tanh((igniterPower - 27.5) / 15) + 1) / 2;

  // 3. Refined non-linear flow rate factor
  // Models that efficiency drops more significantly at lower flow rates.
  // Using a power curve to represent this.
  const flowFactor = 0.6 + 0.4 * Math.pow(flowRate / 100, 1.5);

  // 4. Apply carrier gas and cathode material efficiencies
  const gasFactor = carrierGas.efficiencyFactor;
  const cathodeFactor = cathode.efficiencyFactor;

  // 5. Combine factors to get total thrust gain percentage
  const totalThrustGain = baseBoost * powerFactor * flowFactor * gasFactor * cathodeFactor;
  
  // 6. Calculate final performance metrics
  // Assume Isp gain is proportional to thrust gain, but slightly less (e.g., 50% of the effect)
  const ispGain = totalThrustGain * 0.5;
  
  const enhancedThrust = engine.baseThrust * (1 + totalThrustGain) * (flowRate / 100);
  const enhancedIsp = engine.baseIsp * (1 + ispGain);
  
  // Chamber pressure is a complex output, but we can simulate it rising with thrust
  // FIX: Corrected typo from `flowrate` to `flowRate`.
  const basePressure = engine.chamberPressure * (flowRate / 100);
  const enhancedPressure = basePressure * (1 + totalThrustGain);

  // 7. Calculate Cost-Efficiency Score
  // A simple metric: thrust gain per unit of power input. Higher is better.
  // Add a small constant to avoid division by zero.
  const costEfficiency = (totalThrustGain * 100) / (igniterPower + 0.1);

  // 8. Calculate Plasma Intensity
  // A simulated metric based on power input and component efficiencies.
  const plasmaIntensity = igniterPower * gasFactor * cathodeFactor;

  return {
    thrust: enhancedThrust,
    isp: enhancedIsp,
    chamberPressure: enhancedPressure,
    costEfficiency: costEfficiency,
    plasmaIntensity: plasmaIntensity,
  };
};