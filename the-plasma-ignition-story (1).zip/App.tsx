import React, { useState, useCallback } from 'react';
import { ignitionSystems, plasmaPerformance, comparisonMetrics, realFailures, igniterTiming, ENGINES, CARRIER_GASES, CATHODES, engineSpecs } from './data';
import { EngineTestStand } from './components/EngineTestStand';
import { InfoCard } from './components/InfoCard';
import { ComparisonTable } from './components/ComparisonTable';
import { IgniterDiagramExplained } from './components/IgniterDiagramExplained';
import { ChainReactionDiagram } from './components/ChainReactionDiagram';
import { PropulsionPrimer } from './components/PropulsionPrimer';
import { EngineSpecTable } from './components/EngineSpecTable';
import type { CryogenicEngine, CarrierGas, Cathode } from './types';

const Header = () => (
    <header className="text-center p-8 animate-fade-in-up">
        <div className="flex justify-center items-center mb-4 text-brand-blue-light">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.82m5.84-2.56a12.02 12.02 0 00-5.84-2.56m0 0a12.023 12.023 0 01-5.84-2.56m5.84 2.56V4.72m0 14.72a6 6 0 005.84-7.38m-5.84 2.56a12.023 12.023 0 005.84 2.56m0 0V21m-8.48-1.23a6 6 0 01-5.84-7.38m5.84 2.56a12.023 12.023 0 015.84 2.56m0 0a12.023 12.023 0 00-5.84 2.56m-5.84-2.56a6 6 0 005.84 7.38m0-14.72L9.41 4.72m0 0a12.023 12.023 0 01-5.84 2.56M3.93 7.28a6 6 0 015.84-7.38" />
            </svg>
            <span className="text-2xl font-bold tracking-wider">Group 6- AIM-B</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-50 mb-4 leading-tight">
            THE COMPLETE TRUTH: PLASMA IGNITION
        </h1>
        <p className="text-lg text-brand-text-dim">
            Evidence-Based Analysis with Real Data and Interactive Simulation
        </p>
    </header>
);

const Section = ({ title, children, id }: { title: string, children: React.ReactNode, id: string }) => (
    <section id={id} className="mb-16 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
        <h2 className="text-2xl font-bold text-brand-blue-light mb-6 border-b-2 border-brand-border pb-3 uppercase tracking-wider">
            {title}
        </h2>
        {children}
    </section>
);


const App = () => {
    const [activeReactionStep, setActiveReactionStep] = useState(-1);
    const [selectedEngine, setSelectedEngine] = useState<CryogenicEngine>(ENGINES[0]);
    const [selectedCarrierGas, setSelectedCarrierGas] = useState<CarrierGas>(CARRIER_GASES[0]);
    const [selectedCathode, setSelectedCathode] = useState<Cathode>(CATHODES[0]);

    const handleConfigurationChange = useCallback((config: { engineId?: string; carrierGasId?: string; cathodeId?: string; }) => {
        if (config.engineId) {
            setSelectedEngine(ENGINES.find(e => e.id === config.engineId) || ENGINES[0]);
        }
        if (config.carrierGasId) {
            setSelectedCarrierGas(CARRIER_GASES.find(g => g.id === config.carrierGasId) || CARRIER_GASES[0]);
        }
        if (config.cathodeId) {
            setSelectedCathode(CATHODES.find(c => c.id === config.cathodeId) || CATHODES[0]);
        }
    }, []);


    return (
        <div className="bg-brand-bg text-brand-text font-sans min-h-screen">
            <main className="container mx-auto px-4 py-8 max-w-7xl">
                <Header />

                <Section id="intro-primer" title="A Primer on Rocket Propulsion">
                    <PropulsionPrimer />
                </Section>

                <Section id="intro-problem" title="The Cryogenic Ignition Challenge">
                     <p className="mb-4 text-brand-text-dim">
                       Igniting cryogenic propellants—super-cooled liquids like hydrogen and oxygen—is a monumental engineering challenge. Unlike turning a key in a car, this process involves combining hyper-volatile elements at extreme temperatures in a confined space, all within milliseconds. Traditional methods are often unreliable, leading to several critical failure modes:
                    </p>
                    <ul className="list-disc list-inside space-y-2 text-brand-text-dim pl-4">
                        <li><strong className="text-slate-200">Hard Starts:</strong> An ignition delay allows propellants to accumulate in the chamber, causing a damaging over-pressure event (an explosion) when ignition finally occurs. This was a major concern during SSME development.</li>
                        <li><strong className="text-slate-200">Combustion Instability:</strong> Incomplete or uneven ignition leads to pressure oscillations ("chugging") that can cause catastrophic mechanical failure.</li>
                        <li><strong className="text-slate-200">Restart Failures:</strong> Re-igniting an engine in the vacuum of space is even more difficult. A failure here can mean the loss of a multi-billion dollar satellite or an entire deep-space mission. This has been a persistent issue for upper-stage engines like the RL-10.</li>
                    </ul>
                </Section>

                <Section id="real-failures" title="Real Ignition-Related Failures (Documented)">
                     <p className="mb-6 text-brand-text-dim">
                        The challenges of cryogenic ignition are not theoretical. They are documented, multi-million dollar problems that have affected the most advanced rocket programs in history.
                    </p>
                    <div className="space-y-8">
                        {realFailures.map(failure => (
                            <div key={failure.engine} className="bg-brand-surface p-6 rounded-lg border border-brand-border">
                                <h3 className="text-xl font-bold text-slate-200 mb-4">{failure.engine} {failure.period && `(${failure.period})`}</h3>
                                <ul className="space-y-3">
                                    <li><strong className="text-brand-text-dim w-32 inline-block">Problem:</strong> {failure.problem}</li>
                                    <li><strong className="text-brand-text-dim w-32 inline-block">Root Cause:</strong> {failure.rootCause}</li>
                                    <li><strong className="text-brand-text-dim w-32 inline-block">Solution Adopted:</strong> {failure.solutionAdopted}</li>
                                    <li className="p-3 bg-slate-900/50 rounded-md"><strong className="text-brand-blue-light w-32 inline-block">How Plasma Helps:</strong> <span className="text-slate-200">{failure.howPlasmaHelps}</span></li>
                                </ul>
                            </div>
                        ))}
                    </div>
                </Section>
                
                <Section id="traditional-methods" title="Traditional Methods">
                    <p className="mb-6 text-brand-text-dim">
                        To appreciate the plasma solution, it's essential to understand the limitations of current and historical ignition systems. Each has significant trade-offs in performance, reliability, and complexity.
                    </p>
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                        {ignitionSystems.map(system => (
                            <InfoCard key={system.name} title={system.name} items={[
                                `Works by: ${system.howItWorks}`,
                                `Activation Energy: ${system.activationEnergy}`,
                                `Problems: ${system.problems.join(', ')}`,
                                `Efficiency: ${system.efficiency}`,
                            ]} />
                        ))}
                    </div>
                </Section>

                <Section id="plasma-solution" title="The Plasma Solution: How It Works">
                    <p className="mb-4 text-brand-text-dim">
                        Plasma ignition isn't just an improvement; it's a fundamental shift in strategy. Traditional methods are inefficient, akin to using a flamethrower to light a candle. They waste enormous energy heating a large volume of super-cooled propellants, hoping to reach the required ignition temperature. This brute-force thermal approach is slow, unreliable, and the direct cause of issues like hard starts and combustion instability.
                    </p>
                    <p className="mb-4 text-brand-text-dim">
                        The plasma solution is surgical. Instead of bulk heating, it uses a controlled stream of high-energy plasma—the fourth state of matter—to initiate combustion at a fundamental chemical level. The core principle is this: <strong className="text-slate-200">it's more efficient to break molecules apart than to boil them.</strong>
                    </p>
                    <p className="mb-6 text-brand-text-dim">
                        The plasma jet contains electrons with kinetic energies equivalent to temperatures over 15,000K. These electrons act like molecular-scale bullets, directly impacting and shattering stable propellant molecules (like O₂) into hyper-reactive fragments called <strong className="text-slate-200">radicals</strong>. These radicals are the true key to ignition; they kickstart a chemical chain reaction that spreads through the propellant mixture almost instantly. This "chemical shortcut" provides three definitive advantages:
                    </p>
                    <ul className="list-disc list-inside space-y-2 text-brand-text-dim pl-4 mb-8">
                        <li><strong className="text-slate-200">Unmatched Speed:</strong> Ignition is initiated chemically, not thermally, reducing delay from milliseconds to microseconds.</li>
                        <li><strong className="text-slate-200">Extreme Efficiency:</strong> Energy is precisely targeted at creating radicals, not wasted on heating bulk propellant.</li>
                        <li><strong className="text-slate-200">Total Reliability:</strong> By "seeding" the entire combustion chamber with millions of ignition points (radicals), it ensures a smooth, uniform, and stable burn every time.</li>
                    </ul>
                     <p className="mb-6 text-brand-text-dim">
                        The following diagram and breakdown illustrate the physical components and processes that make this revolutionary approach possible.
                    </p>
                    <IgniterDiagramExplained engine={selectedEngine} carrierGas={selectedCarrierGas} cathode={selectedCathode} />
                </Section>
                
                <Section id="interactive-simulator" title="Interactive Simulator: Real-Time Performance Data">
                    <p className="mb-6 text-brand-text-dim">
                        Configure and "fire" a virtual cryogenic engine to see the real-time impact of plasma ignition. Select different engines, plasma carrier gases, and cathode materials to observe how they affect performance. The model calculates thrust and specific impulse (Isp) based on a non-linear performance model derived from documented plasma-assisted combustion physics.
                    </p>
                    <EngineTestStand
                        onStepChange={setActiveReactionStep}
                        activeStep={activeReactionStep}
                        engine={selectedEngine}
                        carrierGas={selectedCarrierGas}
                        cathode={selectedCathode}
                        onConfigurationChange={handleConfigurationChange}
                    />
                </Section>

                <Section id="chain-reaction" title="The Chemical Chain Reaction (Simplified)">
                    <p className="mb-6 text-brand-text-dim">
                        The key advantage of plasma is its ability to create hyper-reactive chemical species called radicals. These radicals kickstart the combustion chain reaction far more effectively than heat alone. The animation below visualizes the critical steps from electron generation to full-scale combustion.
                    </p>
                    <ChainReactionDiagram activeStep={activeReactionStep} engine={selectedEngine} carrierGas={selectedCarrierGas} cathode={selectedCathode} />
                </Section>
                
                <Section id="performance-comparison" title="Performance Comparison: Plasma vs. Current Systems">
                    <p className="mb-6 text-brand-text-dim">
                        The data below, derived from NIST and academic sources, quantifies the advantages. Plasma significantly reduces the energy needed for ignition and achieves unparalleled speed.
                    </p>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                         {plasmaPerformance.map(perf => (
                            <InfoCard key={perf.fuelSystem} title={perf.fuelSystem} items={[
                                `Baseline Energy: ${perf.thermalBaseline}`,
                                `Plasma Pathway: ${perf.plasmaPathway}`,
                                `Efficiency Gain: ${perf.efficiencyImprovement}`,
                                ...(perf.ignitionDelay ? [`Ignition Delay: ${perf.ignitionDelay}`] : []),
                                ...(perf.powerRequirement ? [`Power Required: ${perf.powerRequirement}`] : []),
                            ]} />
                        ))}
                    </div>
                    <ComparisonTable title="Head-to-Head Metric Comparison" data={comparisonMetrics} />
                </Section>

                 <Section id="results" title="Results">
                    <p className="mb-6 text-brand-text-dim">
                       The following table extrapolates the performance gains from the simulation model onto a range of real-world cryogenic engines. The results show significant, consistent improvements in both thrust and efficiency across different engine cycles and propellant types. Key takeaways from the data include:
                    </p>
                    <ul className="list-disc list-inside space-y-2 text-brand-text-dim pl-4 mb-8">
                        <li><strong className="text-slate-200">Universal Improvement:</strong> Every engine, regardless of country of origin, propellant type, or cycle, shows a notable performance increase. This demonstrates the fundamental and wide-ranging applicability of plasma-assisted combustion.</li>
                        <li><strong className="text-slate-200">High-Thrust Gains:</strong> Major engines like the SSME/RS-25 and SpaceX Raptor show thrust gains exceeding +20%. Such an increase could translate directly to higher payload capacity or more demanding mission profiles.</li>
                        <li><strong className="text-slate-200">Significant Efficiency Boost:</strong> The gains in Specific Impulse (Isp) are substantial, often adding over +20 seconds. For an upper-stage engine, this efficiency gain can mean a significant increase in final payload velocity, enabling more ambitious deep-space missions.</li>
                    </ul>
                    <EngineSpecTable specs={engineSpecs} />
                </Section>

                <Section id="future-discussion" title="Future Discussion">
                    <div className="space-y-6 text-brand-text-dim">
                        <p>While the theoretical and simulated data are overwhelmingly positive, the transition from model to flight-ready hardware involves several engineering challenges and exciting possibilities.</p>
                        <div>
                            <h4 className="font-bold text-slate-300">Next Steps & Challenges:</h4>
                            <ul className="list-disc list-inside pl-4 mt-2">
                                <li><strong>Full-Scale Prototyping:</strong> The immediate next step is to build and test a full-scale plasma igniter integrated with a development engine on a physical test stand to validate these performance gains.</li>
                                <li><strong>Power & Cooling:</strong> Integrating a compact, high-voltage power supply and ensuring adequate thermal management for the igniter within the harsh environment of a rocket engine are critical engineering hurdles.</li>
                                <li><strong>Long-Duration Reliability:</strong> Extensive testing is required to prove the system can withstand hundreds of seconds of firing and multiple restarts without degradation, a key requirement for reusable launch vehicles.</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-bold text-slate-300">Broader Applications:</h4>
                            <ul className="list-disc list-inside pl-4 mt-2">
                                <li><strong>In-Space Propulsion:</strong> The high reliability and restart capability make plasma ignition ideal for interplanetary transfer stages and orbital maneuvering vehicles that may need to fire their engines multiple times over a long mission.</li>
                                <li><strong>Hypersonics & Scramjets:</strong> Plasma can also be used to sustain combustion in air-breathing hypersonic engines, a domain where flame stability is a major challenge.</li>
                                <li><strong>Improving Reusability:</strong> By eliminating pyrophoric igniters like TEA-TEB, plasma ignition simplifies ground operations and reduces turnaround time for reusable rockets like Falcon 9 and Starship.</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-bold text-slate-300">Safety Measures & Protocols:</h4>
                            <p className="mt-2">Testing rocket engines, especially with novel high-energy systems, demands rigorous safety protocols. Key considerations include:</p>
                            <ul className="list-disc list-inside pl-4 mt-2">
                                <li><strong>High-Voltage Isolation:</strong> The plasma igniter's power supply (~3kV) must be fully isolated and shielded. All personnel must follow strict lockout/tagout procedures during maintenance to prevent electrical hazards.</li>
                                <li><strong>Remote Operation & Shielding:</strong> All tests must be conducted from a remote, blast-shielded control room (bunker). The test stand must be equipped with blast deflectors and a robust fire suppression/deluge system.</li>
                                <li><strong>Cryogenic Handling Protocols:</strong> Strict procedures for handling super-cooled propellants are essential to prevent frostbite, material embrittlement, and asphyxiation risks from boil-off gas in enclosed spaces.</li>
                                <li><strong>Automated Shutdown Systems:</strong> The engine control system must include automated "redline" limits that trigger an immediate, safe shutdown if critical parameters (chamber pressure, temperature, voltage) deviate from the expected range.</li>
                            </ul>
                        </div>
                    </div>
                </Section>

                <Section id="conclusion" title="Conclusion">
                    <div className="space-y-4 text-brand-text-dim text-lg leading-relaxed">
                        <p>The challenge of igniting cryogenic propellants has been a persistent bottleneck in rocket engineering, forcing compromises in reliability, complexity, and performance. Traditional methods, from pyrophoric chemicals to high-energy sparks, have proven to be incremental solutions to a fundamental problem.</p>
                        <p className="text-slate-200 font-semibold">Plasma ignition represents a paradigm shift. By fundamentally altering the chemical pathway to combustion through the generation of radicals, it offers a solution that is simultaneously faster, more efficient, and more reliable.</p>
                        <p>The evidence presented—from the analysis of historical failures and the head-to-head data comparison to the interactive simulation and projected gains on real-world engines—converges on a single, unambiguous conclusion: plasma-assisted combustion is a key enabling technology. It holds the potential to unlock the next generation of launch vehicles, enhance our deep-space capabilities, and make access to space more reliable and cost-effective than ever before.</p>
                    </div>
                </Section>

            </main>
        </div>
    );
};

export default App;